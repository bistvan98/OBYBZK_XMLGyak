package domOBYBZK1026;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

public class Main {

	public static void main(String[] args) {
		DomWriteOBYBZK domWriteOBYBZK = new DomWriteOBYBZK();
		try {
			domWriteOBYBZK.write();
		} catch (ParserConfigurationException | TransformerException e) {
			e.printStackTrace();
		}
	}

}
