package hu.domparse.obybzk;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DOMQueryObybzk {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		
		File xmlFile = new File("src/hu/domparse/obybzk/XMLObybzk.xml");
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = factory.newDocumentBuilder();
		
		Document doc = dBuilder.parse(xmlFile);
		
		doc.getDocumentElement().normalize();
		
		System.out.println("Root: " + doc.getDocumentElement().getNodeName() + "\n");
		
		// Kiirja azokat a futarokat, akiknek suzuki autojuk van
		System.out.println("A suzuki-t hasznalo futarok neve: \n");
		
		NodeList nodeList = doc.getElementsByTagName("futar");
		
		boolean foundAny = false;
		
		for(int i = 0; i < nodeList.getLength(); i++) {
			
			Node node = nodeList.item(i);
			
			if(node.getNodeType() == Node.ELEMENT_NODE) {
				Element elem = (Element) node;
				
				Node node2;
				
				// Megvizsgalom az autoja tipusat
				node2 = elem.getElementsByTagName("auto").item(0);
				String carType = node2.getTextContent();
				
				// Ha suzuki, akkor kiirom a futar nevet
				if("suzuki".equals(carType)) {
					Node nodeName = elem.getElementsByTagName("nev").item(0);
					String name = nodeName.getTextContent();
					
					System.out.println(name + "\n");
					
					foundAny = true;
				}
			}
			
		}
		
		if(foundAny == false) {
			
			System.out.println("\n Nem talalhato olyan futar, aki suzukit vezet. \n");
		}
		else {
			foundAny = false;
		}
			
		// Kiirja azoknak az ettermek a nevet, ahol kaphato gyros
		System.out.println("\n Gyrost arulo ettermek: \n");
		
		nodeList = doc.getElementsByTagName("etel");
		
		foundAny = false;
		
		for(int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			
			if(node.getNodeType() == Node.ELEMENT_NODE) {
				Element elem = (Element) node;
				
				Node node2;
				
				// Megvizsgalja az eteleket
				node2 = elem.getElementsByTagName("etel_neve").item(0);
				String foodName = node2.getTextContent();
				
				// Ha gyros, akkor kiirja az etelt aurlo etterem adoszamat
				if("gyros".equals(foodName)) {
					
					String taxNumber = elem.getAttribute("Adoszam_e");
					
					System.out.println(taxNumber + "\n");
					
					foundAny = true;
					
				}
			}
		}
		
		if(foundAny == false) {
			System.out.println("\n Nem talalhato olyan etterem az adatbazisban, amelyik arul gyrost.\n");
		}
		
	}

}
